/**----------------------------------------------------------------------
Class Name: Utilities
Description: This java class suffice for all reusable & common methods/functions through our framework
and capable of extending to all open source test automation tools  
Date of Creation: 14/04/2020
Extends: NA
Implements: NA
Author: Leela, Sriram
-------------------------------------------------------------------------
Update Log: NA
Date: NA By: NA Details: NA
------------------------------------------------------------------------*/

package planit.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



/**
 * The Class has all WebActions i.e Selenium reusable actions, test data extraction methods...etc.
 *
 * @author Sriram
 */

public class WebActions {

	protected static WebDriver driver;

	
	public static int timeOut = 60;

	public static HashMap<String, String> testData = new HashMap<String, String>();
	public static HashMap<String, String> inputData = new HashMap<String, String>();

	/**
	 * ----------------------------------------------------------------------
	 * Method Name: getData() Description: This method is the most robust &
	 * reusable hat can support extracting required test data from different xls
	 * & csv file. 
	 * Date of Creation: 29/04/2020 
	 * Input Arguments: String
	 * excelname,String sheetName, String testCase 
	 * Return Parameters: inputData
	 * Exception Used: e.getMessage()
	 * -------------------------------------------------------------------------
	 * Update Log: NA Date:NA By:NA Details: NA
	 * ------------------------------------------------------------------------
	 */

	public static HashMap<String, String> getData(String excelname, String sheetName, String testCase)
			throws Exception {

		try {

			FileInputStream file = new FileInputStream(new File("testData/" + excelname + ""));
			HSSFWorkbook workbook = new HSSFWorkbook(file);
			HSSFSheet sheet = workbook.getSheet(sheetName);

			int rowCount = sheet.getPhysicalNumberOfRows();
			int ColumnCount = sheet.getRow(0).getPhysicalNumberOfCells();

			System.out.println(rowCount + "*******************" + ColumnCount);

			for (int i = 0; i < rowCount; i++) {
				if (sheet.getRow(i).getCell(0).toString().equals(testCase)
						&& sheet.getRow(i).getCell(1).toString().equals("Yes")) {

					for (int k = 0; k < ColumnCount; k++) {
						inputData.put(sheet.getRow(0).getCell(k).toString(),
								sheet.getRow(i).getCell(k).getStringCellValue());
					}
					break;

				}
			}
			file.close();

		} catch (Exception e) {
			e.getMessage();
		}
		return inputData;
	}

	public static void launchApplication(WebDriver driver, String url) {

		driver.get(url);

	}

	public static void click(WebDriver driver, String xpath) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, timeOut);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));

		WebElement clickOnThis = driver.findElement(By.xpath(xpath));

		JavascriptExecutor jse = (JavascriptExecutor) driver;

		((JavascriptExecutor) driver).executeScript("arguments[0].click();", clickOnThis);

		Thread.sleep(4000);

	}

	public static boolean waitDForElementToDisappear(WebDriver driver, String xpath) {

		int timeOut = 5;

		WebDriverWait wait = new WebDriverWait(driver, timeOut);

		return wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(xpath)));

	}

	public static void doubleClick(WebDriver driver, String xpath) {

		Actions action = new Actions(driver);
		WebElement element = driver.findElement(By.xpath(xpath));
		action.doubleClick(element).perform();

	}

	public static void highlightElement(WebDriver driver, String xpath) {

		WebDriverWait wait = new WebDriverWait(driver, timeOut);

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));

		WebElement clickOnThis = driver.findElement(By.xpath(xpath));

		JavascriptExecutor jse = (JavascriptExecutor) driver;

		jse.executeScript("arguments[0].setAttribute('style', arguments[1]);", clickOnThis,
				"color: red, border: 10px solid red;");

	}

}
