package planit.tests;

import org.testng.annotations.Test;
import planit.factory.PageinstancesFactory;
import planit.pages.ContactPage;
import planit.util.WebActions;

/**
 * The Class FaceBookLoginTest.
 *
 * @author Bharathish
 */
@Test(testName = "TC02_Validate successful submission message")
public class SubmissionTest extends BaseTest {
	
	@Test(invocationCount = 3)
	public void tc02ContactTest() throws Exception {
		WebActions.testData = WebActions.getData("PlanitTest.xls", "Testing",
				"TC02_Validate successful submission message");
		setup(getData("Browser"));
		driver.get(getData("Url"));
		ContactPage contactPage = PageinstancesFactory.getInstance(ContactPage.class);
		contactPage.verifySuccessfulSubmission();

	}
	

	public String getData(String getDataFor) {

		return WebActions.testData.get(getDataFor);

	}
}
