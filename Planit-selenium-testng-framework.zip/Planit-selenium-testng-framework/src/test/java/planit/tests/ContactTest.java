package planit.tests;

import org.testng.annotations.Test;
import planit.factory.PageinstancesFactory;
import planit.pages.ContactPage;
import planit.util.WebActions;

/**
 * The Class FaceBookLoginTest.
 *
 * @author Bharathish
 */
@Test(testName = "TC01_Validate errors messages in Contact page")
public class ContactTest extends BaseTest {

	@Test
	public void tc01ContactTest() throws Exception {
		WebActions.testData = WebActions.getData("PlanitTest.xls", "Testing",
				"TC01_Validate errors messages in Contact page");
		setup(getData("Browser"));
		driver.get(getData("Url"));
		ContactPage contactPage = PageinstancesFactory.getInstance(ContactPage.class);
		contactPage.verifyErrorMsgsContact();

	}
	
	
	public String getData(String getDataFor) {

		return WebActions.testData.get(getDataFor);

	}
}
