package planit.tests;

import org.testng.annotations.Test;
import planit.factory.PageinstancesFactory;
import planit.pages.ContactPage;
import planit.pages.ShopPage;
import planit.util.WebActions;

/**
 * The Class FaceBookLoginTest.
 *
 * @author Bharathish
 */
@Test(testName = "TC03_Verify the items are in the cart & total amount compared with subtotals")
public class ShoppingTest extends BaseTest {

	
	@Test
	public void tc03ContactTest() throws Exception {
		WebActions.testData = WebActions.getData("PlanitTest.xls", "Testing",
				"TC03_Verify the items are in the cart");
		setup(getData("Browser"));
		driver.get(getData("Url"));
		ShopPage shopPage = PageinstancesFactory.getInstance(ShopPage.class);
		shopPage.buyItems();
		shopPage.verifyCartItems();
	}
	
	
	@Test
	public void tc04ContactTest() throws Exception {
		WebActions.testData = WebActions.getData("PlanitTest.xls", "Testing",
				"TC04_Verify the item and totals in the cart");
		setup(getData("Browser"));
		driver.get(getData("Url"));
		ShopPage shopPage = PageinstancesFactory.getInstance(ShopPage.class);
		shopPage.buyItems();
		shopPage.verifyCartItems();
		shopPage.verifyCartItemTotal();
	}
	

	public String getData(String getDataFor) {

		return WebActions.testData.get(getDataFor);

	}
}
