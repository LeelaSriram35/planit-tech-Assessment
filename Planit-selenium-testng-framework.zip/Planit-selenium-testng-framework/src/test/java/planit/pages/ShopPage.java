package planit.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import planit.util.LoggerUtil;
import planit.util.ReportUtil;
import planit.util.WebActions;

/**
 * The Class has all Shop page related web elements & methods as per requirements
 *
 * @author Sriram
 */

public class ShopPage extends BasePage {

	WebActions webActions;

	public ShopPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static double tempSubTotal;

	

	@FindBy(xpath = "//a[text()='Shop']")
	private WebElement shop;

	@FindBy(xpath = "//*[@id='nav-cart']/a")
	private WebElement cart;

	public String getData(String getDataFor) {

		return webActions.testData.get(getDataFor);

	}

	

	/**
	 * ----------------------------------------------------------------------
	 * Method Name: buyItems() 
	 * Description: This method is reusable method to buy items that can be added to cart with Item & Quantity combinations
	 * Date of Creation: 15/05/2020 
	 * Input Arguments: NA
	 * Return Parameters: void()
	 * Note *** Dynamic xpath has been implemented as per business test logic
	 * -------------------------------------------------------------------------
	 * Update Log: NA Date:NA By:NA Details: NA
	 * ------------------------------------------------------------------------
	 */
	public void buyItems() throws InterruptedException {

		ReportUtil.addScreenShot("Click on Shop link to navigate to Shop page");

		shop.click();

		Thread.sleep(5000);

		String[] buyItems = getData("BuyItems").split("%");

		for (int i = 0; i < buyItems.length; i++) {

			String[] quantity = buyItems[i].split(",");

			for (int j = 0; j < quantity.length; j++) {

				if (j == 1) {

					int val = Integer.parseInt(quantity[j]);

					for (int j2 = 1; j2 <= val; j2++) {

						driver.findElement(By.xpath("//h4[text()='" + quantity[0] + "']/..//a")).click();

					}
				}

			}

			ReportUtil.addScreenShot("Items purchased : " + buyItems[i]);

		}

		ReportUtil.addScreenShot("Click on cart link to navigate to cart page");
		cart.click();
		Thread.sleep(5000);
	}

	/**
	 * ----------------------------------------------------------------------
	 * Method Name: verifyCartItems()
	 * Description: This method is used to verify cart items added from list (test data)
	 * Date of Creation: 15/05/2020 
	 * Input Arguments: NA
	 * Return Parameters: void()
	 * Note *** Dynamic xpath has been implemented as per business test logic
	 * -------------------------------------------------------------------------
	 * Update Log: NA Date:NA By:NA Details: NA
	 * ------------------------------------------------------------------------
	 */

	public void verifyCartItems() throws InterruptedException {

		String[] buyItems = getData("BuyItems").split("%");

		for (int i = 0; i < buyItems.length; i++) {

			String[] quantity = buyItems[i].split(",");

			for (int j = 0; j < quantity.length; j++) {

				if (j == 0) {

					driver.findElement(By.xpath("//td[text()=' " + quantity[0] + "']")).isDisplayed();

					ReportUtil.addScreenShot("Verify Cart items which are ready to check out : " + buyItems[i]);

				}
			}
		}

	}
	
	
	/**
	 * ----------------------------------------------------------------------
	 * Method Name: verifyCartItemTotal()
	 * Description: This method is used to verify cart items added from list (test data)
	 * Date of Creation: 15/05/2020 
	 * Input Arguments: NA
	 * Return Parameters: void()
	 * Note *** Dynamic xpath has been implemented as per business test logic
	 * -------------------------------------------------------------------------
	 * Update Log: NA Date:NA By:NA Details: NA
	 * ------------------------------------------------------------------------
	 */
	

	public void verifyCartItemTotal() throws InterruptedException {

		String[] buyItems = getData("BuyItems").split("%");

		for (int i = 0; i < buyItems.length; i++) {

			String[] quantity = buyItems[i].split(",");

			for (int j = 0; j < quantity.length; j++) {

				if (j == 0) {

					String cartItem = quantity[j];

					String price = driver.findElement(By.xpath("//td[text()=' " + cartItem + "']/..//td[2]")).getText();

					String quantityUnits = driver
							.findElement(By.xpath("//td[text()=' " + cartItem + "']/..//input[@name='quantity']"))
							.getAttribute("value");

					String subTotal = driver.findElement(By.xpath("//td[text()=' " + cartItem + "']/..//td[4]"))
							.getText();

					assertEquals(Double.parseDouble(price.replace("$", "")) * Integer.parseInt(quantityUnits),
							Double.parseDouble(subTotal.replace("$", "")));

					tempSubTotal = tempSubTotal + Double.parseDouble(subTotal.replace("$", ""));

					ReportUtil.logMessage(
							"Verify the expected cart Item " + cartItem + " with Price * quantity = SubTotal: "
									+ Double.parseDouble(price.replace("$", "")) * Integer.parseInt(quantityUnits),
							"Successful");

				}

			}

		}

		double total = Double
				.parseDouble(driver.findElement(By.xpath("//tfoot/tr[1]/td/strong")).getText().replace("Total:", ""));
		assertEquals(tempSubTotal, total);
		ReportUtil.addScreenShot("Verify total: " + total + " is matching with Sum(subtotals): " + tempSubTotal
				+ ", Verification done successfully");

	}

}
