package planit.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import planit.util.LoggerUtil;
import planit.util.ReportUtil;
import planit.util.WebActions;


/**
 * The Class has all Contact page related web elements & methods as per requirements
 *
 * @author Sriram
 */

public class ContactPage extends BasePage {

	WebActions webActions;

	public ContactPage(WebDriver driver) {
		super(driver);
	}

	public static double tempSubTotal;

	/** The email input. */
	@FindBy(xpath = "//a[text()='Contact']")
	private WebElement contact;

	/** The pass. */
	@FindBy(xpath = "//a[text()='Submit']")
	private WebElement submit;

	@FindBy(xpath = "//span[text()='Forename is required']")
	private WebElement foreNameError;

	@FindBy(xpath = "//span[text()='Email is required']")
	private WebElement emailError;

	@FindBy(xpath = "//span[text()='Message is required']")
	private WebElement messageError;

	@FindBy(xpath = "//input[@id='forename']")
	private WebElement forename;

	@FindBy(xpath = "//input[@id='email']")
	private WebElement email;

	@FindBy(xpath = "//textarea[@id='message']")
	private WebElement message;

	@FindBy(xpath = "//div/strong/following::text()[1]")
	private WebElement successMsg1;

	@FindBy(xpath = "//span[text()='Please enter a valid email']")
	private WebElement validEmail;

	@FindBy(xpath = "//a[text()='Shop']")
	private WebElement shop;

	@FindBy(xpath = "//*[@id='nav-cart']/a")
	private WebElement cart;

	public String getData(String getDataFor) {

		return webActions.testData.get(getDataFor);

	}

	
	/**
	 * ----------------------------------------------------------------------
	 * Method Name: verifyErrorMsgsContact() 
	 * Description: This method is used to verify error messages on the contact page
	 * Date of Creation: 15/05/2020 
	 * Input Arguments: NA
	 * 
	 * -------------------------------------------------------------------------
	 */
	public ContactPage verifyErrorMsgsContact() throws InterruptedException {

		ReportUtil.addScreenShot(" From the home page go to contact page after clicking on Contact link");
		contact.click();
		submit.click();
		foreNameError.isDisplayed();
		emailError.isDisplayed();
		messageError.isDisplayed();
		ReportUtil.addScreenShot(" Click on on Submit and validate errors are displayed successfully");
		LoggerUtil.log("Error messages are validated successfully");

		forename.clear();
		forename.sendKeys(getData("Forename"));
		email.clear();
		email.sendKeys(getData("Email"));
		message.clear();
		message.sendKeys(getData("Message"));
		ReportUtil.addScreenShot("Populate mandatory fields and validate errors are gone");
		return this;
	}

	/**
	 * ----------------------------------------------------------------------
	 * Method Name: verifySuccessfulSubmission() 
	 * Description: This method is used to verify successful submission if all mandated fields are given in contact page
	 * Date of Creation: 15/05/2020 
	 * Input Arguments: NA
	 * 
	 * -------------------------------------------------------------------------
	 */	
	public ContactPage verifySuccessfulSubmission() throws InterruptedException {
		ReportUtil.addScreenShot(" From the home page go to contact page after clicking on Contact link");
		contact.click();
		forename.clear();
		forename.sendKeys(getData("Forename"));
		email.clear();
		email.sendKeys(getData("Email"));
		message.clear();
		message.sendKeys(getData("Message"));
		ReportUtil.addScreenShot("Populate mandatory fields and validate errors are gone");
		submit.click();
		Thread.sleep(5000);
		ReportUtil.addScreenShot("Validate successful submission message");

		return this;
	}

}
